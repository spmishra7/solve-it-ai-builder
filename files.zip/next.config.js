/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: [
      'avatars.githubusercontent.com',
      'lh3.googleusercontent.com',
      'ui-avatars.com',
    ],
  },
  env: {
    NEXTAUTH_URL: process.env.NEXTAUTH_URL,
    DATABASE_URL: process.env.DATABASE_URL,
    STRIPE_PUBLISHABLE_KEY: process.env.STRIPE_PUBLISHABLE_KEY,
  },
  webpack: (config) => {
    // Enable proper source maps in development mode
    if (!process.env.NODE_ENV !== 'production') {
      config.devtool = 'eval-source-map';
    }
    return config;
  },
};

module.exports = nextConfig;