import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { z } from 'zod';
import { prisma } from '@/lib/db/prisma';
import { authOptions } from '@/pages/api/auth/[...nextauth]';
import { SchemaType } from '@/lib/ai/generator';
import { logger } from '@/utils/logger';

// Schema validation
const createProjectSchema = z.object({
  name: z.string().min(3).max(100),
  description: z.string().max(500),
  requirements: z.string(),
  schemaType: z.nativeEnum(SchemaType),
  isPublic: z.boolean().optional(),
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Check authentication
  const session = await getServerSession(req, res, authOptions);
  
  if (!session || !session.user) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  // Handle GET request - list user's projects
  if (req.method === 'GET') {
    try {
      const projects = await prisma.project.findMany({
        where: {
          OR: [
            { ownerId: session.user.id },
            { isPublic: true },
          ],
        },
        orderBy: {
          updatedAt: 'desc',
        },
      });
      
      return res.status(200).json(projects);
    } catch (error) {
      logger.error('Failed to fetch projects', { error, userId: session.user.id });
      return res.status(500).json({ message: 'Failed to fetch projects' });
    }
  }
  
  // Handle POST request - create new project
  if (req.method === 'POST') {
    try {
      // Validate input
      const validatedData = createProjectSchema.parse(req.body);
      
      // Check user's subscription for project limits
      const user = await prisma.user.findUnique({
        where: { id: session.user.id },
        include: { subscription: true },
      });
      
      // Count existing projects
      const projectCount = await prisma.project.count({
        where: { ownerId: session.user.id },
      });
      
      // Check if user exceeded project limit
      const planId = user?.subscription?.planId || 'FREE';
      const planLimits = {
        FREE: 5,
        PRO: -1, // unlimited
        ENTERPRISE: -1, // unlimited
      };
      
      const projectLimit = planLimits[planId] || 5;
      
      if (projectLimit !== -1 && projectCount >= projectLimit) {
        return res.status(403).json({
          message: `You've reached the limit of ${projectLimit} projects for your plan. Please upgrade to create more.`,
        });
      }
      
      // Create new project
      const project = await prisma.project.create({
        data: {
          name: validatedData.name,
          description: validatedData.description,
          schema: {}, // This will be populated in the schema generation step
          isPublic: validatedData.isPublic || false,
          owner: {
            connect: { id: session.user.id },
          },
          // Store requirements and schema type for generation
          generatedFiles: {
            requirements: validatedData.requirements,
            schemaType: validatedData.schemaType,
          },
        },
      });
      
      return res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      
      logger.error('Failed to create project', { error, userId: session.user.id });
      return res.status(500).json({ message: 'Failed to create project' });
    }
  }
  
  // Reject other methods
  return res.status(405).json({ message: 'Method not allowed' });
}