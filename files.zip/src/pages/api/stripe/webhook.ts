import { NextApiRequest, NextApiResponse } from 'next';
import { buffer } from 'micro';
import Stripe from 'stripe';
import { handleSubscriptionEvent } from '@/lib/payments/stripe';
import { logger } from '@/utils/logger';

// Disable Next.js body parsing
export const config = {
  api: {
    bodyParser: false,
  },
};

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const buf = await buffer(req);
  const sig = req.headers['stripe-signature']!;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

  let event: Stripe.Event;

  try {
    if (!sig || !webhookSecret) {
      throw new Error('Stripe webhook secret or signature is missing');
    }
    
    event = stripe.webhooks.constructEvent(buf, sig, webhookSecret);
  } catch (err) {
    logger.error('Webhook signature verification failed', { error: err.message });
    return res.status(400).json(`Webhook Error: ${err.message}`);
  }

  try {
    // Handle the event
    if (event.type.startsWith('customer.subscription') || 
        event.type.startsWith('checkout.session') || 
        event.type.startsWith('invoice')) {
      await handleSubscriptionEvent(event);
    }

    return res.status(200).json({ received: true });
  } catch (error) {
    logger.error('Error handling webhook event', { error, eventType: event.type });
    return res.status(500).json({ message: 'Error handling webhook event' });
  }
}