import { z } from 'zod';

// Schema definitions for validation
export const UserSchema = z.object({
  id: z.string().uuid().optional(),
  email: z.string().email(),
  name: z.string().min(2).max(100),
  role: z.enum(['ADMIN', 'USER', 'DEVELOPER']),
  createdAt: z.date().optional(),
  updatedAt: z.date().optional(),
});

export const ProjectSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(3).max(100),
  description: z.string().max(500),
  schema: z.record(z.any()),
  ownerId: z.string().uuid(),
  createdAt: z.date().optional(),
  updatedAt: z.date().optional(),
});

export const ApiKeySchema = z.object({
  id: z.string().uuid().optional(),
  key: z.string(),
  name: z.string().min(1),
  userId: z.string().uuid(),
  lastUsed: z.date().optional(),
  createdAt: z.date().optional(),
});

export const SubscriptionSchema = z.object({
  id: z.string().uuid().optional(),
  userId: z.string().uuid(),
  planId: z.string(),
  status: z.enum(['ACTIVE', 'CANCELED', 'PAST_DUE']),
  currentPeriodEnd: z.date(),
  stripeCustomerId: z.string().optional(),
  stripeSubscriptionId: z.string().optional(),
});

// Type definitions derived from schemas
export type User = z.infer<typeof UserSchema>;
export type Project = z.infer<typeof ProjectSchema>;
export type ApiKey = z.infer<typeof ApiKeySchema>;
export type Subscription = z.infer<typeof SubscriptionSchema>;