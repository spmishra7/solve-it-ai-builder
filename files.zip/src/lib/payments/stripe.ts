import Stripe from 'stripe';
import { prisma } from '../db/prisma';
import { logger } from '@/utils/logger';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

// Plan definitions
export const PLANS = {
  FREE: {
    id: 'free',
    name: 'Free',
    price: 0,
    features: ['5 projects', 'Basic schema generation', 'Community support'],
    limits: {
      projects: 5,
      apiCalls: 100,
      deployments: 1,
    },
  },
  PRO: {
    id: 'pro',
    name: 'Professional',
    price: 29,
    features: ['Unlimited projects', 'Advanced schema generation', 'API code generation', 'Email support'],
    limits: {
      projects: -1, // unlimited
      apiCalls: 5000,
      deployments: 10,
    },
    stripePriceId: process.env.STRIPE_PRICE_ID_PRO,
  },
  ENTERPRISE: {
    id: 'enterprise',
    name: 'Enterprise',
    price: 99,
    features: ['Unlimited everything', 'Custom integrations', 'Dedicated support', 'SSO', 'Audit logs'],
    limits: {
      projects: -1, // unlimited
      apiCalls: -1, // unlimited
      deployments: -1, // unlimited
    },
    stripePriceId: process.env.STRIPE_PRICE_ID_ENTERPRISE,
  },
};

// Create a checkout session for subscription
export async function createCheckoutSession(userId: string, planId: string, returnUrl: string) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { subscription: true },
    });

    if (!user) {
      throw new Error('User not found');
    }

    const plan = PLANS[planId.toUpperCase()];
    
    if (!plan || !plan.stripePriceId) {
      throw new Error('Invalid plan or plan not configured for payments');
    }

    // Get or create Stripe customer
    let stripeCustomerId = user.subscription?.stripeCustomerId;
    
    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.name,
        metadata: {
          userId,
        },
      });
      stripeCustomerId = customer.id;
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: stripeCustomerId,
      line_items: [
        {
          price: plan.stripePriceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${returnUrl}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${returnUrl}/canceled`,
      metadata: {
        userId,
        planId,
      },
    });

    return { url: session.url, sessionId: session.id };
  } catch (error) {
    logger.error('Failed to create checkout session', { error, userId, planId });
    throw new Error(`Payment session creation failed: ${error.message}`);
  }
}

// Handle webhook for subscription events
export async function handleSubscriptionEvent(event: Stripe.Event) {
  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        
        if (session.mode !== 'subscription') return;
        
        const { userId, planId } = session.metadata as { userId: string; planId: string };
        
        // Update user subscription
        await prisma.subscription.upsert({
          where: { userId },
          create: {
            userId,
            planId,
            status: 'ACTIVE',
            stripeCustomerId: session.customer as string,
            stripeSubscriptionId: session.subscription as string,
            currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // +30 days
          },
          update: {
            planId,
            status: 'ACTIVE',
            stripeCustomerId: session.customer as string,
            stripeSubscriptionId: session.subscription as string,
            currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // +30 days
          },
        });
        
        break;
      }
      
      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        
        if (!invoice.subscription) return;
        
        // Update subscription period
        const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
        
        await prisma.subscription.updateMany({
          where: { stripeSubscriptionId: invoice.subscription as string },
          data: {
            status: 'ACTIVE',
            currentPeriodEnd: new Date(subscription.current_period_end * 1000),
          },
        });
        
        break;
      }
      
      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        
        if (!invoice.subscription) return;
        
        await prisma.subscription.updateMany({
          where: { stripeSubscriptionId: invoice.subscription as string },
          data: {
            status: 'PAST_DUE',
          },
        });
        
        break;
      }
      
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        
        await prisma.subscription.updateMany({
          where: { stripeSubscriptionId: subscription.id },
          data: {
            status: 'CANCELED',
          },
        });
        
        break;
      }
    }
  } catch (error) {
    logger.error('Failed to handle subscription event', { error, eventType: event.type });
    throw error;
  }
}

// Cancel subscription
export async function cancelSubscription(userId: string) {
  try {
    const subscription = await prisma.subscription.findUnique({
      where: { userId },
    });
    
    if (!subscription || !subscription.stripeSubscriptionId) {
      throw new Error('No active subscription found');
    }
    
    await stripe.subscriptions.del(subscription.stripeSubscriptionId);
    
    await prisma.subscription.update({
      where: { userId },
      data: {
        status: 'CANCELED',
      },
    });
    
    return { success: true };
  } catch (error) {
    logger.error('Failed to cancel subscription', { error, userId });
    throw new Error(`Subscription cancellation failed: ${error.message}`);
  }
}