import OpenAI from 'openai';
import { z } from 'zod';
import { logger } from '@/utils/logger';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Schema template types
export enum SchemaType {
  DATABASE = 'DATABASE',
  API = 'API',
  GRAPHQL = 'GRAPHQL',
}

// Prompt templates
const PROMPTS = {
  [SchemaType.DATABASE]: 
    `Generate a comprehensive database schema for the following requirements: 
     {{requirements}}
     
     Include tables, columns, data types, relationships, and constraints.
     Format the response as a valid JSON object.`,
     
  [SchemaType.API]:
    `Create an OpenAPI 3.1 specification for the following requirements:
     {{requirements}}
     
     Include paths, methods, request/response schemas, and security definitions.
     Format the response as a valid JSON object conforming to OpenAPI 3.1.`,
     
  [SchemaType.GRAPHQL]:
    `Design a GraphQL schema for the following requirements:
     {{requirements}}
     
     Include types, queries, mutations, and subscriptions.
     Format the response as a valid GraphQL SDL (Schema Definition Language).`
};

// Response validators
const validators = {
  [SchemaType.DATABASE]: z.record(z.any()),
  [SchemaType.API]: z.record(z.any()),
  [SchemaType.GRAPHQL]: z.string(),
};

export async function generateSchema(
  requirements: string,
  type: SchemaType,
  options: {
    temperature?: number;
    maxTokens?: number;
  } = {}
): Promise<any> {
  try {
    const prompt = PROMPTS[type].replace('{{requirements}}', requirements);
    
    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo',
      messages: [
        { role: 'system', content: 'You are a schema generation assistant specializing in creating high-quality schemas for software applications.' },
        { role: 'user', content: prompt }
      ],
      temperature: options.temperature || 0.3,
      max_tokens: options.maxTokens || 4000,
    });
    
    const result = response.choices[0]?.message.content;
    
    if (!result) {
      throw new Error('No schema generated');
    }
    
    // Parse and validate the result based on schema type
    let parsedResult;
    
    if (type === SchemaType.GRAPHQL) {
      // GraphQL schemas are returned as strings
      parsedResult = result.trim();
    } else {
      // Extract JSON from the response
      const jsonMatch = result.match(/```json([\s\S]*?)```/) || result.match(/({[\s\S]*})/);
      const jsonStr = jsonMatch ? jsonMatch[1] : result;
      
      try {
        parsedResult = JSON.parse(jsonStr);
      } catch {
        throw new Error('Failed to parse JSON response');
      }
    }
    
    // Validate the parsed result
    validators[type].parse(parsedResult);
    
    return {
      schema: parsedResult,
      tokenUsage: {
        prompt: response.usage?.prompt_tokens || 0,
        completion: response.usage?.completion_tokens || 0,
        total: response.usage?.total_tokens || 0,
      }
    };
  } catch (error) {
    logger.error('Schema generation failed', { error, type, requirementsExcerpt: requirements.substring(0, 100) });
    throw new Error(`Failed to generate ${type} schema: ${error.message}`);
  }
}

// Schema optimization function
export async function optimizeSchema(schema: any, type: SchemaType, feedback: string): Promise<any> {
  try {
    const schemaStr = typeof schema === 'string' ? schema : JSON.stringify(schema, null, 2);
    
    const prompt = `
      Optimize the following ${type} schema based on this feedback:
      
      FEEDBACK:
      ${feedback}
      
      CURRENT SCHEMA:
      ${schemaStr}
      
      Provide the optimized schema only, maintaining the same format.
    `;
    
    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo',
      messages: [
        { role: 'system', content: 'You are a schema optimization assistant. Your task is to improve existing schemas based on user feedback.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 4000,
    });
    
    const result = response.choices[0]?.message.content;
    
    if (!result) {
      throw new Error('No optimization result generated');
    }
    
    // Parse the result based on schema type
    let parsedResult;
    
    if (type === SchemaType.GRAPHQL) {
      parsedResult = result.trim();
    } else {
      const jsonMatch = result.match(/```json([\s\S]*?)```/) || result.match(/({[\s\S]*})/);
      const jsonStr = jsonMatch ? jsonMatch[1] : result;
      
      try {
        parsedResult = JSON.parse(jsonStr);
      } catch {
        throw new Error('Failed to parse JSON response');
      }
    }
    
    // Validate the parsed result
    validators[type].parse(parsedResult);
    
    return {
      schema: parsedResult,
      tokenUsage: {
        prompt: response.usage?.prompt_tokens || 0,
        completion: response.usage?.completion_tokens || 0,
        total: response.usage?.total_tokens || 0,
      }
    };
  } catch (error) {
    logger.error('Schema optimization failed', { error, type });
    throw new Error(`Failed to optimize ${type} schema: ${error.message}`);
  }
}