import React, { useState } from 'react';
import { useRouter } from 'next/router';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { SchemaType } from '@/lib/ai/generator';
import Button from '@/components/ui/Button';
import TextArea from '@/components/ui/TextArea';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Alert from '@/components/ui/Alert';

// Form validation schema
const projectFormSchema = z.object({
  name: z.string().min(3, 'Project name must be at least 3 characters').max(100),
  description: z.string().min(10, 'Description must be at least 10 characters').max(500),
  requirements: z.string().min(20, 'Requirements must be at least 20 characters'),
  schemaType: z.nativeEnum(SchemaType),
  isPublic: z.boolean().optional(),
});

type ProjectFormValues = z.infer<typeof projectFormSchema>;

interface ProjectFormProps {
  initialValues?: Partial<ProjectFormValues>;
  isEditing?: boolean;
}

export default function ProjectForm({ initialValues, isEditing = false }: ProjectFormProps) {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ProjectFormValues>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      name: initialValues?.name || '',
      description: initialValues?.description || '',
      requirements: initialValues?.requirements || '',
      schemaType: initialValues?.schemaType || SchemaType.DATABASE,
      isPublic: initialValues?.isPublic || false,
    },
  });
  
  // Handle form submission
  const onSubmit = async (data: ProjectFormValues) => {
    setIsSubmitting(true);
    setError(null);
    
    try {
      const endpoint = isEditing
        ? `/api/projects/${router.query.id}`
        : '/api/projects';
        
      const method = isEditing ? 'PUT' : 'POST';
      
      const response = await fetch(endpoint, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to save project');
      }
      
      const result = await response.json();
      
      // Redirect to the project page or schema generation page
      if (isEditing) {
        router.push(`/projects/${result.id}`);
      } else {
        router.push(`/projects/${result.id}/schema`);
      }
    } catch (err) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {error && (
        <Alert type="error" title="Error">
          {error}
        </Alert>
      )}
      
      <div>
        <Input
          label="Project Name"
          {...register('name')}
          error={errors.name?.message}
          disabled={isSubmitting}
        />
      </div>
      
      <div>
        <TextArea
          label="Description"
          {...register('description')}
          error={errors.description?.message}
          disabled={isSubmitting}
          rows={3}
        />
      </div>
      
      <div>
        <Select
          label="Schema Type"
          {...register('schemaType')}
          error={errors.schemaType?.message}
          disabled={isSubmitting}
        >
          <option value={SchemaType.DATABASE}>Database Schema</option>
          <option value={SchemaType.API}>API Specification</option>
          <option value={SchemaType.GRAPHQL}>GraphQL Schema</option>
        </Select>
      </div>
      
      <div>
        <TextArea
          label="Project Requirements"
          {...register('requirements')}
          error={errors.requirements?.message}
          disabled={isSubmitting}
          rows={6}
          placeholder="Describe your project requirements in detail. The more specific you are, the better schema we can generate. Include entities, their properties, relationships, and any special requirements."
        />
      </div>
      
      <div className="flex items-center">
        <input
          id="isPublic"
          type="checkbox"
          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          {...register('isPublic')}
        />
        <label htmlFor="isPublic" className="ml-2 block text-sm text-gray-900">
          Make this project public
        </label>
      </div>
      
      <div className="flex justify-end space-x-3">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
          disabled={isSubmitting}
        >
          Cancel
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {isEditing ? 'Save Changes' : 'Create Project'}
        </Button>
      </div>
    </form>
  );
}